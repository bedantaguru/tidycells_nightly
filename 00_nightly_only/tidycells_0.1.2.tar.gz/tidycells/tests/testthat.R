library(testthat)
library(tidycells)

test_check("tidycells")
