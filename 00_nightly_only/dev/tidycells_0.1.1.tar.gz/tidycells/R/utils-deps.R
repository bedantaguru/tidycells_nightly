#### dplyr ####

#' @importFrom dplyr bind_rows
NULL

#' @importFrom dplyr distinct
NULL

#' @importFrom dplyr ungroup
NULL

#' @importFrom dplyr group_split
NULL

#' @importFrom dplyr pull
NULL

#' @importFrom dplyr rename
NULL

#' @importFrom dplyr arrange
NULL

#' @importFrom dplyr full_join
NULL

#' @importFrom dplyr inner_join
NULL

#' @importFrom dplyr right_join
NULL

#' @importFrom dplyr left_join
NULL

#' @importFrom dplyr anti_join
NULL

#' @importFrom dplyr select
NULL

#' @importFrom dplyr filter
NULL

#' @importFrom dplyr group_by
NULL

#' @importFrom dplyr mutate
NULL

#' @importFrom dplyr mutate_all
NULL

#' @importFrom dplyr summarise
NULL

#' @importFrom dplyr n
NULL

#' @importFrom dplyr count
NULL

#' @importFrom dplyr case_when
NULL

#' @importFrom dplyr recode
NULL

#' @importFrom dplyr n_distinct
NULL


#### tibble ####

#' @importFrom tibble tibble
NULL

#' @importFrom tibble as_tibble
NULL


#### purrr ####

#' @importFrom purrr map
NULL

#' @importFrom purrr map_df
NULL

#' @importFrom purrr map_lgl
NULL

#' @importFrom purrr map_dbl
NULL

#' @importFrom purrr map_int
NULL

#' @importFrom purrr map_chr
NULL

#' @importFrom purrr reduce
NULL


#### unpivotr ####

#' @importFrom unpivotr enhead
NULL

#### rlang ####

#' @importFrom rlang abort
NULL

#' @importFrom rlang warn
NULL
