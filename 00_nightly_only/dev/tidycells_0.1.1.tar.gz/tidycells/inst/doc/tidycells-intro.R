## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include = FALSE----------------------------------------------
library(tidycells)

## ---- eval=FALSE---------------------------------------------------------
#  read_cells(file_name)

## ---- echo = TRUE, eval = FALSE------------------------------------------
#  devtools::install_github("r-rudra/tidycells")

## ------------------------------------------------------------------------
fold <- system.file("extdata", "messy", package = "tidycells", mustWork = TRUE)
# this is because extension is intentionally given wrong  
# while filename is actual identifier of the file type
fcsv <- list.files(fold, pattern = "^csv.", full.names = TRUE)[1]
read_cells(fcsv)

## ------------------------------------------------------------------------
utils::read.csv(fcsv)

## ---- eval=FALSE---------------------------------------------------------
#  read_cells()

## ---- out.width = "550px", echo=FALSE------------------------------------
knitr::include_graphics("ext/read_cells_out.png")

## ------------------------------------------------------------------------
d1 <- read_cells(fcsv, at_level = "va_classify") %>% 
  read_cells()
d2 <- read_cells(fcsv, at_level = 2) %>% 
  read_cells(at_level = 4) %>% 
  read_cells()
identical(d1, d2)

## ------------------------------------------------------------------------
x <- iris %>% head() 
cd <- x %>% as_cell_df(take_col_names = TRUE)

## ---- eval=FALSE---------------------------------------------------------
#  plot(cd, adaptive_txt_size = FALSE, txt_size = 2.5)

## ---- out.width = "356px", echo=FALSE------------------------------------
knitr::include_graphics("ext/pr/p1.png")

## ------------------------------------------------------------------------
dummy_dat <- tibble::tibble(name = c("Mr. X", "Mr. Y"), sal = c("1,000","12,000"), age = c(35, 60))
dummy_dat
dummy_dat_cells <- dummy_dat %>% 
  as_cell_df(take_col_names = TRUE) 

## ------------------------------------------------------------------------
va_cells <- numeric_values_classifier(dummy_dat_cells)

## ------------------------------------------------------------------------
va_cells <- value_attribute_classify(dummy_dat_cells, 
                                     classifier = numeric_values_classifier())

## ---- fig.width=3, fig.height=2, eval=FALSE------------------------------
#  plot(va_cells, adaptive_txt_size = FALSE, txt_size = 3)

## ---- out.width = "256px", echo=FALSE------------------------------------
knitr::include_graphics("ext/pr/p2.png")

## ---- eval=FALSE---------------------------------------------------------
#  # let's resume with iris example
#  cd <- numeric_values_classifier(cd)
#  plot(cd, adaptive_txt_size = FALSE, txt_size = 2.5)

## ---- out.width = "356px", echo=FALSE------------------------------------
knitr::include_graphics("ext/pr/p3.png")

## ---- echo=FALSE---------------------------------------------------------
cd <- numeric_values_classifier(cd)

## ------------------------------------------------------------------------
ca <- analyze_cells(cd)

## ---- eval=FALSE---------------------------------------------------------
#  plot(ca)

## ---- out.width = "356px", echo=FALSE------------------------------------
knitr::include_graphics("ext/pr/p4.png")

## ------------------------------------------------------------------------
compose_cells(ca)

## ---- fig.width=3, fig.height=2, eval=FALSE------------------------------
#  cell_composition_traceback(ca, trace_row = 1)
#  cell_composition_traceback(ca, trace_row = 10)

## ---- out.width = "356px", echo=FALSE------------------------------------
knitr::include_graphics("ext/pr/p5.png")

## ------------------------------------------------------------------------
rc_part <- read_cells(fcsv, at_level = 2)
# it is a list with `read_cells_stage` attribute
# which indicate the last processed stage in read_cells
str(rc_part)
# sample_based_classifier is another VA classifier
# for details see coresponding documentation
rc_part[[1]] <- rc_part[[1]] %>% sample_based_classifier(empty_sample = "6")

# below should be similar to 
# rc_part[[1]] %>% 
#   analyze_cells() %>% 
#   compose_cells(discard_raw_cols = TRUE)
rc_part %>% read_cells(from_level = 3)

## ------------------------------------------------------------------------
dm <- tibble::tibble(fn = list.files(fold, full.names = T))
dm$fn %>% basename()

## ---- echo=FALSE, include=FALSE------------------------------------------
# filter based on file-type
dm <- dm %>%
    dplyr::mutate(original = dm$fn %>%
      purrr::map_chr(~ basename(.x) %>%
        stringr::str_split("\\.") %>%
        purrr::map_chr(1)))
if(!(rlang::is_installed("readxl") | rlang::is_installed("xlsx"))){
  dm <- dm %>% dplyr::filter(original!="xls")
}
if(!(rlang::is_installed("tidyxl"))){
  dm <- dm %>% dplyr::filter(original!="xlsx")
}
if(!(rlang::is_installed("docxtractr"))){
  dm <- dm %>% dplyr::filter(original!="docx" & original!="doc")
}
if(!(rlang::is_installed("tabulizer"))){
  dm <- dm %>% dplyr::filter(original!="pdf")
}
if(!(rlang::is_installed("XML"))){
  dm <- dm %>% dplyr::filter(original!="html")
}

## ------------------------------------------------------------------------
dcomps <- dm$fn %>% purrr::map(read_cells)
dcomps_sel <- dcomps %>%
    purrr::map(~ .x %>%
      dplyr::select(value, major_1, major_2))
# all of them are same [intentionaly made. but the file types are totally different]
dcomps_sel %>% purrr::map_lgl(~identical(.x, dcomps_sel[[1]]))
# check one sample
dcomps_sel[[1]]


## ---- out.width = "516px", echo=FALSE------------------------------------
knitr::include_graphics("ext/v12.png")

## ---- out.width = "516px", echo=FALSE------------------------------------
knitr::include_graphics("ext/v34.png")

## ---- out.width = "516px", echo=FALSE------------------------------------
knitr::include_graphics("ext/v56.png")

